#if defined(UNICODE) && !defined(_UNICODE)
    #define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
    #define UNICODE
#endif

#include <tchar.h>
#include <windows.h>
#include <CommCtrl.h>
#include "resource.h"

/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgPort(HWND hPort, UINT Msg, WPARAM wParam, LPARAM lParam);
void getport();                   /* Get port # from combobox and write it to label and variable */
int open_serialCom();             /* Open the serial port */
int close_serialCom();            /* Close the serial port */
void button_sync();

/*  Make the class name into a global variable  */
TCHAR szClassName[ ] = _T("WindowsApp");
HINSTANCE hInstance;
HANDLE hserial;                   /* Give Serial port a name */
HWND hwndButton1 = 0;             /* Used to select com port */
HWND hwndButton2 = 0;             /* Used to toggle led 1 on/off */
HWND hwndButton3 = 0;             /* Used to toggle led 2 on/off */
HWND hwndButton4 = 0;             /* Used to toggle led 3 on/off */
int serial_port_good = 0;         /* Keeps track if serial port is there */
int led_1_on = 0;                 /* Keeps track of led 1 state */
int led_2_on = 0;                 /* Keeps track of led 2 state */
int led_3_on = 0;                 /* Keeps track of led 3 state */
int selectedIndex = 4;            /* Used to hold retrived index from port combobox */
int serial_port;                  /* Holds the COM port # */

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nCmdShow)
{
    open_serialCom();             /* Open the serial port */

    HWND hwnd;                    /* This is the handle for our window */
    MSG messages;                 /* Here messages to the application are saved */
    WNDCLASSEX wincl;             /* Data structure for the windowclass */

    /* The Window structure */
    wincl.hInstance = hInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_HREDRAW | CS_VREDRAW;
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (hInstance, MAKEINTRESOURCE(IDI_ICON));
    wincl.hIconSm = LoadIcon (hInstance, MAKEINTRESOURCE(IDI_ICONSM));
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;    /* No menu */
    wincl.cbClsExtra = 0;         /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;         /* structure or the window instance */
    /* Use Windows's default color as the background of the window */
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    int initialX = (screenWidth - 680) / 2;
    int initialY = (screenHeight - 300) / 2;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                     /* Extended possibilites for variation */
           szClassName,           /* Classname */
           _T("Windows LED Controller"),         /* Title Text */
           WS_POPUP | WS_CAPTION | WS_SYSMENU,   /* default window */
           initialX,              /* The window horizontal position */
           initialY,              /* The window vertical position */
           680,                   /* The programs width in pixels */
           300,                   /* The programs height in pixels */
           HWND_DESKTOP,          /* The window is a child-window to desktop */
           NULL,                  /* No menu */
           hInstance,             /* Program Instance handler */
           NULL                   /* No Window Creation data */
           );

    /* Make the window visible on the screen */
    ShowWindow (hwnd, nCmdShow);
    UpdateWindow(hwnd);

    getport();                    /* Get port # from combobox and write it to label and variable */

    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0))
    {
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }

    /* The program return-value is 0 - The value that PostQuitMessage() gave */
    return messages.wParam;
}


/*  This function is called by the Windows function DispatchMessage()  */

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)              /* handle the messages */
    {
        case WM_CREATE:
        {
            hwndButton1 = CreateWindowEx(
                0,
                "BUTTON",
                "",
                WS_CHILD | WS_VISIBLE | WS_BORDER | BS_OWNERDRAW,
                5, 4, 75, 22,
                hwnd,
                (HMENU)IDC_BUTTON1,
                hInstance,
                NULL);

            hwndButton2 = CreateWindowEx(
                0,
                "BUTTON",
                "TXD Led off",
                WS_CHILD | WS_VISIBLE | WS_BORDER | BS_OWNERDRAW,
                20, 45, 200, 200,
                hwnd,
                (HMENU)IDC_BUTTON2,
                hInstance,
                NULL);

            hwndButton3 = CreateWindowEx(
                0,
                "BUTTON",
                "DTR Led off",
                WS_CHILD | WS_VISIBLE | WS_BORDER | BS_OWNERDRAW,
                240, 45, 200, 200,
                hwnd,
                (HMENU)IDC_BUTTON3,
                hInstance,
                NULL);

            hwndButton4 = CreateWindowEx(
                0,
                "BUTTON",
                "RTS Led off",
                WS_CHILD | WS_VISIBLE | WS_BORDER | BS_OWNERDRAW,
                460, 45, 200, 200,
                hwnd,
                (HMENU)IDC_BUTTON4,
                hInstance,
                NULL);
        }
        break;

    case WM_COMMAND:
    {
        switch (LOWORD (wParam))
        {
            case IDC_BUTTON1:
            DialogBox(hInstance, MAKEINTRESOURCE(DLG_PORT), NULL, (DLGPROC)DlgPort);
            break;

            case IDC_BUTTON2:
            if (serial_port_good == 1)
            {
                if (led_1_on == 1)
                {
                     EscapeCommFunction(hserial, CLRBREAK);
                     led_1_on = 0;
                     SetWindowText(hwndButton2, "TXD Led off");
                }
                else
                {
                    EscapeCommFunction(hserial, SETBREAK);
                    led_1_on = 1;
                    SetWindowText(hwndButton2, "TXD Led on");
                }
            }
            else
            {
                MessageBox(0, "No serial port to power LED 1.", "LED Button 1", MB_OK);
            }
            break;

            case IDC_BUTTON3:
            if (serial_port_good == 1)
            {
                if (led_2_on == 1)
                {
                     EscapeCommFunction(hserial, CLRDTR);
                     led_2_on = 0;
                     SetWindowText(hwndButton3, "DTR Led off");
                }
                else
                {
                    EscapeCommFunction(hserial, SETDTR);
                    led_2_on = 1;
                    SetWindowText(hwndButton3, "DTR Led on");
                }
            }
            else
            {
                MessageBox(0, "No serial port to power LED 2.", "LED Button 2", MB_OK);
            }
            break;

            case IDC_BUTTON4:
            if (serial_port_good == 1)
            {
                if (led_3_on == 1)
                {
                     EscapeCommFunction(hserial, CLRRTS);
                     led_3_on = 0;
                     SetWindowText(hwndButton4, "RTS Led off");
                }
                else
                {
                    EscapeCommFunction(hserial, SETRTS);
                    led_3_on = 1;
                    SetWindowText(hwndButton4, "RTS Led on");
                }
            }
            else
            {
                MessageBox(0, "No serial port to power LED 3.", "LED Button 3", MB_OK);
            }
            break;
        }
    }
    break;

    case WM_DRAWITEM:
    {
        LPDRAWITEMSTRUCT lpDrawItem = (LPDRAWITEMSTRUCT)lParam;
        if (lpDrawItem->hwndItem == hwndButton1)
        {
            if (serial_port_good == 1)
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(0, 255, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton1, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
            else
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(255, 0, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton1, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
        }
        if (lpDrawItem->hwndItem == hwndButton2)
        {
            if (led_1_on == 1)
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(0, 255, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton2, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
            else
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(255, 0, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton2, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
        }
        if (lpDrawItem->hwndItem == hwndButton3)
        {
            if (led_2_on == 1)
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(0, 255, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton3, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
            else
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(255, 0, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton3, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
        }
        if (lpDrawItem->hwndItem == hwndButton4)
        {
            if (led_3_on == 1)
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(0, 255, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton4, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
            else
            {
                HDC hdc = lpDrawItem->hDC;
                RECT rc = lpDrawItem->rcItem;
                COLORREF newBgColor = RGB(255, 0, 0);
                HBRUSH hBrush = CreateSolidBrush(newBgColor);
                FillRect(hdc, &rc, hBrush);
                DeleteObject(hBrush);
                CHAR staticText[99];
                SetBkMode(hdc, TRANSPARENT);
                SendMessage(hwndButton4, WM_GETTEXT, ARRAYSIZE(staticText), (LPARAM)staticText);
                DrawText(hdc, staticText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                return TRUE;
            }
        }
    }
    break;

    case WM_DESTROY:
        PostQuitMessage (0);  /* send a WM_QUIT to the message queue */
        break;
        default:                  /* for messages that we don't deal with */
        return DefWindowProc (hwnd, message, wParam, lParam);
    break;
    }

    return 0;
}

BOOL CALLBACK DlgPort(HWND hPort, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    switch(Msg)
    {
    case WM_INITDIALOG:                               /* Add content to the combobox */
    {
        HWND hComboBox = GetDlgItem(hPort, IDC_COMBOBOX_PORT);
        if (hComboBox)
        {
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("1"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("2"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("3"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("4"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("5"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("6"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("7"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("8"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("9"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("10"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("11"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("12"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("13"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("14"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("15"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("16"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("17"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("18"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("19"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("20"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("21"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("22"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("23"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("24"));
            SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM) TEXT ("25"));
        }
    }
    return TRUE;

    case WM_COMMAND:
    {
            switch (HIWORD (wParam))
            {
                case CBN_SELCHANGE:
                {
                    HWND hComboBox = (HWND)lParam;
                    selectedIndex = SendMessage(hComboBox, CB_GETCURSEL, 0, 0);
                    getport();
                }
                break;
                return 0;
            }
        switch(LOWORD(wParam))
        {
        case IDCLOSE:
            EndDialog(hPort, IDCLOSE);
            return TRUE;
        }
        break;
    }
    return TRUE;
    }
    return FALSE;
}

int open_serialCom()                                  /* Open the serial port */
{

        switch (serial_port)                          /* Holds the COM port # */
        {
            case 1:                                   /* Comport 1 */
            hserial = CreateFile("\\\\.\\COM1", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 2:                                   /* Comport 2 */
            hserial = CreateFile("\\\\.\\COM2", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 3:                                   /* Comport 3 */
            hserial = CreateFile("\\\\.\\COM3", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 4:                                   /* Comport 4 */
            hserial = CreateFile("\\\\.\\COM4", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 5:                                   /* Comport 5 */
            hserial = CreateFile("\\\\.\\COM5", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 6:                                   /* Comport 6 */
            hserial = CreateFile("\\\\.\\COM6", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 7:                                   /* Comport 7 */
            hserial = CreateFile("\\\\.\\COM7", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 8:                                   /* Comport 8 */
            hserial = CreateFile("\\\\.\\COM8", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 9:                                   /* Comport 9 */
            hserial = CreateFile("\\\\.\\COM9", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 10:                                  /* Comport 10 */
            hserial = CreateFile("\\\\.\\COM10", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 11:                                  /* Comport 11 */
            hserial = CreateFile("\\\\.\\COM11", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 12:                                  /* Comport 12 */
            hserial = CreateFile("\\\\.\\COM12", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 13:                                  /* Comport 13 */
            hserial = CreateFile("\\\\.\\COM13", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 14:                                  /* Comport 14 */
            hserial = CreateFile("\\\\.\\COM14", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 15:                                  /* Comport 15 */
            hserial = CreateFile("\\\\.\\COM15", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 16:                                  /* Comport 16 */
            hserial = CreateFile("\\\\.\\COM16", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 17:                                  /* Comport 17 */
            hserial = CreateFile("\\\\.\\COM17", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 18:                                  /* Comport 18 */
            hserial = CreateFile("\\\\.\\COM18", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 19:                                  /* Comport 19 */
            hserial = CreateFile("\\\\.\\COM19", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 20:                                  /* Comport 20 */
            hserial = CreateFile("\\\\.\\COM20", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 21:                                  /* Comport 21 */
            hserial = CreateFile("\\\\.\\COM21", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 22:                                  /* Comport 22 */
            hserial = CreateFile("\\\\.\\COM22", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 23:                                  /* Comport 23 */
            hserial = CreateFile("\\\\.\\COM23", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 24:                                  /* Comport 24 */
            hserial = CreateFile("\\\\.\\COM24", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            case 25:                                  /* Comport 25 */
            hserial = CreateFile("\\\\.\\COM25", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            break;

            default:                                  /* Capture anything else here */
            break;
        }

    if (hserial == INVALID_HANDLE_VALUE)
    {
        serial_port_good = 0;
        button_sync();
    }
    else
    {
        serial_port_good = 1;
        button_sync();
    }
    return 0;
}

int close_serialCom()                                 /* Close the serial port */
{
    CloseHandle(hserial);                             /* Close Serial port */
    if(CloseHandle(hserial) == 1)
    {
    }
    else
    {
        serial_port_good = 0;
    }
    return 0;
}

void getport()                    /* Get port # from combobox and write it to label and variable */
{
    close_serialCom();
    switch(selectedIndex)
    {
    case 0:
        SetWindowText(hwndButton1, "Com  1");
        serial_port = 1;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 1:
        SetWindowText(hwndButton1, "Com  2");
        serial_port = 2;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 2:
        SetWindowText(hwndButton1, "Com  3");
        serial_port = 3;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 3:
        SetWindowText(hwndButton1, "Com  4");
        serial_port = 4;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 4:
        SetWindowText(hwndButton1, "Com  5");
        serial_port = 5;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 5:
        SetWindowText(hwndButton1, "Com  6");
        serial_port = 6;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 6:
        SetWindowText(hwndButton1, "Com  7");
        serial_port = 7;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 7:
        SetWindowText(hwndButton1, "Com  8");
        serial_port = 8;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 8:
        SetWindowText(hwndButton1, "Com  9");
        serial_port = 9;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 9:
        SetWindowText(hwndButton1, "Com 10");
        serial_port = 10;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 10:
        SetWindowText(hwndButton1, "Com 11");
        serial_port = 11;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 11:
        SetWindowText(hwndButton1, "Com 12");
        serial_port = 12;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 12:
        SetWindowText(hwndButton1, "Com 13");
        serial_port = 13;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 13:
        SetWindowText(hwndButton1, "Com 14");
        serial_port = 14;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 14:
        SetWindowText(hwndButton1, "Com 15");
        serial_port = 15;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 15:
        SetWindowText(hwndButton1, "Com 16");
        serial_port = 16;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 16:
        SetWindowText(hwndButton1, "Com 17");
        serial_port = 17;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 17:
        SetWindowText(hwndButton1, "Com 18");
        serial_port = 18;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 18:
        SetWindowText(hwndButton1, "Com 19");
        serial_port = 19;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 19:
        SetWindowText(hwndButton1, "Com 20");
        serial_port = 20;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 20:
        SetWindowText(hwndButton1, "Com 21");
        serial_port = 21;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 21:
        SetWindowText(hwndButton1, "Com 22");
        serial_port = 22;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 22:
        SetWindowText(hwndButton1, "Com 23");
        serial_port = 23;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 23:
        SetWindowText(hwndButton1, "Com 24");
        serial_port = 24;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
        break;
    case 24:
        SetWindowText(hwndButton1, "Com 25");
        serial_port = 25;
        open_serialCom();
        InvalidateRect(hwndButton1, NULL, TRUE);
       break;
    }
}

void button_sync()
{
    if (serial_port_good == 1)
    {
        SetWindowText(hwndButton3, "DTS Led on");
        led_2_on = 1;
        InvalidateRect(hwndButton3, NULL, TRUE);
        SetWindowText(hwndButton4, "RTS Led on");
        led_3_on = 1;
        InvalidateRect(hwndButton4, NULL, TRUE);
    }
    else
    {
        SetWindowText(hwndButton3, "DTS Led off");
        led_2_on = 0;
        InvalidateRect(hwndButton3, NULL, TRUE);
        SetWindowText(hwndButton4, "RTS Led off");
        led_3_on = 0;
        InvalidateRect(hwndButton4, NULL, TRUE);
    }
    return;
}
