
#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDI_ICON              201
#define IDI_ICONSM            202
#define DLG_PORT              300
#define IDC_BUTTON1          2000
#define IDC_BUTTON2          2001
#define IDC_BUTTON3          2002
#define IDC_BUTTON4          2003
#define IDC_COMBOBOX_PORT    2004
